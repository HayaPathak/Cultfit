# Connected Website

This package contains the six uploaded HTML pages connected using the filenames already referenced by their navigation links.

## Pages
- `index.html` — Home / Page 3
- `booking.html` — Booking / Book
- `feed.html` — Feed
- `history.html` — History
- `profile.html` — Profile
- `growth.html` — Growth

## Run locally
Because this is a static frontend, you can run it with any static web server. For example:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/`.

## Backend
No backend source files were included in the uploaded files, so this package does not invent or add a backend. The six frontend pages and their navigation are connected and ready to run as a static site.
